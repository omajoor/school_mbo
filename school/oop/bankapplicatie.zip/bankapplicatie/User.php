<?php
require_once "Bankaccount.php";
class User
{
    private $Name;
    private $PinCode;
    private $SavingsAccount;
    private $CheckingAccount;
    
    public function __construct($name, $pincode, $savingsAccountNumber, $checkingAccountNumber)
    {
        $this->Name            = $name;
        $this->PinCode         = $pincode;
        $this->SavingsAccount  = new BankAccount("saving account", $savingsAccountNumber);
        $this->CheckingAccount = new BankAccount("checking account", $checkingAccountNumber);
        
    }
    
    public function getname()
    {
        return $this->Name;
    }
    
    public function getSavingsAccount()
    {
        return $this->SavingsAccount;
    }
    
    public function getCheckingAccount()
    {
        return $this->CheckingAccount;
    }
    
    public function deposit($amount)
    {
        
        return $this->CheckingAccount->deposit($amount);
        
    }
    public function withdraw($amount)
    {
        return $this->CheckingAccount->withdraw($amount);
    }
    public function TransferToCheckingAccount($amount)
    {
        if ($this->SavingsAccount->withdraw($amount) != "too poor") {
            $this->CheckingAccount->deposit($amount);
            return "gelukt";
        } else {
            return "te weinig cash";
        }
        
    }
    
    public function TransferToSavingsAccount($amount)
    {
        if ($this->CheckingAccount->withdraw($amount) != "too poor") {
            $this->SavingsAccount->deposit($amount);
            return "gelukt";
        } else {
            return "te weinig cash";
        }
    }
    
    public function CheckAllBalances()
    {
        $all = "SavingAccount: " . $this->SavingsAccount->getBalance() . "<br> CheckingAccount: " . $this->CheckingAccount->getBalance();
        return $all;
    }

    public function CalculateRent()
    {
        return "Je rente voor De Checkingaccount is € " . 
        $this->CheckingAccount->CalculateRent() . "<br>Je rente voor De SavingsAccount is € ". 
        $this->SavingsAccount->CalculateRent();
    }
    
    
}

?>
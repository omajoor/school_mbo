<?php
class BankAccount
{
    
    private $Type;
    private $Balance = 50;
    private $RentPercentage = 10;
    private $AccountNumber;
    
    
    public function __construct($type, $accountNumber)
    {
        $this->Type          = $type;
        $this->AccountNumber = $accountNumber;
    }
    
    public function getType()
    {
        return $this->Type;
    }
    
    public function getBalance()
    {
        return $this->Balance;
    }
    
    public function withdraw($amount)
    {
        if ($this->Balance - $amount > 0) {
            $this->Balance = $this->Balance - $amount;
            return $this->Balance;
        } else {
            return "too poor";
        }
    }
    public function deposit($amount)
    {
        $this->Balance = $this->Balance + $amount;
        return $this->Balance;
    }
    public function CalculateRent()
    {
       return $this->Balance/100*$this->RentPercentage;
    }
    
    public function setBalance($balance)
    {
        $this->Balance = $balance;
    }
    
    
    
}


?>
<?php
define(DBNAME , "localhost");
echo DBNAME;

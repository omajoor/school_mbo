<h1>Registreer</h1>   


<div class="row">
    
    <div class="col-6">

        <form action="./index.php?content=register" method="post">
          <div class="form-group">
            <label for="exampleInputEmail1">E-mail adres</label>
            <input type="email" class="form-control" id="email" name="email" aria-describedby="emailHelp" placeholder="Voer E-mail in">
            <small id="emailhelp" class="form-text text-muted">We zullen nooit uw E-mail met iemand anders delen</small>
          </div>
        
          <button type="submit" class="btn btn-info btn-lg btn-block">Submit</button>
        </form>

    </div>
    <div class="col-6"> <img src="./img/rose.png" alt="rose"></div>

</div> 
